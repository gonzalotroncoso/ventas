
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">

<link rel="stylesheet" type="text/css" href="../librerias/alertify/css/alertify.css">
<link rel="stylesheet" type="text/css" href="../librerias/alertify/css/themes/default.css">
<link rel="stylesheet" type="text/css" href="../librerias/bootstrap/css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="../librerias/select2/css/select2.css">
<link rel="stylesheet" type="text/css" href="../css/menu.css">





<script src="../librerias/jquery-3.2.1.min.js"></script>
<script src="../librerias/bootstrap/js/bootstrap.js"></script>
<script src="../librerias/select2/js/select2.js"></script>
<script src="../librerias/alertify/alertify.js"></script>
<script src="../js/funciones.js"></script>
